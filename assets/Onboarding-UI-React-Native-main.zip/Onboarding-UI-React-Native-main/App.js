import AppNavigation from './navigation/appNavigation';

export default function App() {
  return (
    <AppNavigation />
  );
}
